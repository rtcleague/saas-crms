from typing import List, Dict, Any
from openai import AsyncOpenAI
from loguru import logger
from core.config import settings
from models.order import OrderResponse

class LLMService:
    def __init__(self):
        self.client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
        self.model = settings.OPENAI_MODEL

    async def analyze_conversation(self, messages: List[Dict[str, Any]], call_metadata: Dict[str, Any]) -> OrderResponse:
        """
        Analyze conversation using OpenAI GPT-4 to extract order details
        """
        system_prompt = """
        You are an AI assistant tasked with analyzing a conversation between a customer and a sales bot about an iPhone order.
        Extract relevant order details and structure them according to the specified format below.

        Required JSON Format:
        {
            "order_details": {
                "order_id": "string",
                "timestamp": "ISO datetime string",
                "customer_info": {
                    "name": "string or null",
                    "phone": "string or null",
                    "email": "string or null",
                    "address": "string or null"
                },
                "product_details": {
                    "model": "string or null",
                    "storage": "string or null",
                    "color": "string or null",
                    "price": "number or null"
                },
                "addons": {
                    "apple_care": "boolean",
                    "apple_care_price": "number or null",
                    "accessories": [
                        {
                            "item": "string",
                            "price": "number or null"
                        }
                    ]
                },
                "delivery_method": "string or null",
                "notification_method": "string or null",
                "status": "completed | pending | cancelled"
            },
            "metadata": {
                "created_at": "ISO datetime string",
                "call_duration": "number (seconds)",
                "status": "string",
                "version": "1.0"
            }
        }

        Instructions:
        1. Analyze the conversation to extract all relevant order information
        2. For any missing information, use null values
        3. The response MUST strictly follow the JSON format above
        4. For timestamps, use ISO format (e.g., "2024-03-19T14:30:00Z")
        5. For status, use only: "completed", "pending", or "cancelled"
        6. Generate a unique order_id if not specified in conversation
        7. Use the call_metadata provided for duration and timestamps
        8. All price values should be numbers without currency symbols

        Focus on identifying:
        1. Customer information (name, contact details, address)
        2. Product details (iPhone model, storage, color, price)
        3. Additional services (Apple Care, accessories)
        4. Delivery and notification preferences
        5. Order status (completed/pending/cancelled)
        """

        try:
            conversation_text = "\n".join([
                f"{msg['role']}: {msg['content']}"
                for msg in messages
            ])

            # Add call metadata to the conversation context
            metadata_text = f"\nCall Duration: {call_metadata['call_duration']} seconds\nStart Time: {call_metadata['start_time']}\nEnd Time: {call_metadata['end_time']}"
            
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": f"{conversation_text}\n\nMetadata:{metadata_text}"}
                ],
                temperature=0.1,  # Low temperature for more consistent structured output
                response_format={ "type": "json_object" }  # Ensure JSON response
            )

            # Parse the response and validate it against our model
            llm_response = response.choices[0].message.content
            logger.info(f"Raw LLM Response: {llm_response}")

            # Parse the JSON response and create an OrderResponse object
            order_response = OrderResponse.parse_raw(llm_response)
            logger.info(f"Parsed Order Response: {order_response.dict()}")
            
            return order_response

        except Exception as e:
            logger.error(f"Error in LLM service: {str(e)}")
            raise 