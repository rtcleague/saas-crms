from typing import Dict, Any
from loguru import logger
from .llm_service import LLMService

class ConversationService:
    def __init__(self):
        self.llm_service = LLMService()

    async def process_conversation(self, payload: Dict[Any, Any]) -> Dict[str, Any]:
        """
        Process the conversation payload and extract order details using LLM
        """
        try:
            # Extract messages and metadata from the payload
            messages = payload['conversation']['messages']
            call_metadata = payload['conversation']['metadata']
            
            # Log the input for debugging
            logger.info(f"Processing conversation with {len(messages)} messages")
            logger.info(f"Call metadata: {call_metadata}")
            
            # Analyze conversation using LLM
            order_analysis = await self.llm_service.analyze_conversation(
                messages=messages,
                call_metadata=call_metadata
            )
            
            result = {
                "status": "success",
                "message": "Conversation analyzed successfully",
                "data": order_analysis.dict()
            }
            
            logger.info(f"Final response: {result}")
            return result

        except Exception as e:
            logger.error(f"Error processing conversation: {str(e)}")
            return {
                "status": "error",
                "message": f"Error processing conversation: {str(e)}",
                "data": None
            } 