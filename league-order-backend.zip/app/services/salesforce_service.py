import os
from dotenv import load_dotenv
from simple_salesforce import Salesforce
from firebase_admin import credentials, initialize_app, db
from loguru import logger

# Load environment variables
load_dotenv()

class SalesforceService:
    def __init__(self):
        # Initialize Firebase
        cred = credentials.Certificate({
            "type": os.getenv("FIREBASE_TYPE"),
            "project_id": os.getenv("FIREBASE_PROJECT_ID"),
            "private_key_id": os.getenv("FIREBASE_PRIVATE_KEY_ID"),
            "private_key": os.getenv("FIREBASE_PRIVATE_KEY").replace('\\n', '\n'),
            "client_email": os.getenv("FIREBASE_CLIENT_EMAIL"),
            "client_id": os.getenv("FIREBASE_CLIENT_ID"),
            "auth_uri": os.getenv("FIREBASE_AUTH_URI"),
            "token_uri": os.getenv("FIREBASE_TOKEN_URI"),
            "auth_provider_x509_cert_url": os.getenv("FIREBASE_AUTH_PROVIDER_X509_CERT_URL"),
            "client_x509_cert_url": os.getenv("FIREBASE_CLIENT_X509_CERT_URL"),
            "universe_domain": os.getenv("FIREBASE_UNIVERSE_DOMAIN")
        })
        initialize_app(cred, {
            'databaseURL': os.getenv('FIREBASE_DATABASE_URL')
        })

        # Initialize Salesforce
        self.sf = Salesforce(
            username=os.getenv('SALESFORCE_USERNAME'),
            password=os.getenv('SALESFORCE_PASSWORD'),
            security_token=os.getenv('SALESFORCE_SECURITY_TOKEN')
        )

    def create_price_book(self, price_book_name):
        """Create a new price book in Salesforce"""
        price_book_data = {'Name': price_book_name, 'IsActive': True}
        response = self.sf.Pricebook2.create(price_book_data)
        logger.info(f"Price Book created with ID: {response['id']}")
        return response['id']

    def create_product(self, product_name, description, product_code):
        """Create a new product in Salesforce"""
        product_data = {
            'Name': product_name,
            'IsActive': True,
            'Description': description,
            'ProductCode': product_code
        }
        response = self.sf.Product2.create(product_data)
        logger.info(f"Product created with ID: {response['id']}")
        return response['id']

    def create_price_book_entry(self, product_id, unit_price):
        """Create a price book entry for a product"""
        try:
            # Set default unit price if None
            if unit_price is None:
                unit_price = 0.0
                logger.warning(f"Unit price is None, defaulting to 0 for product {product_id}")

            # First, get the ID of the standard price book
            standard_price_book_query = self.sf.query("SELECT Id FROM Pricebook2 WHERE IsStandard = true LIMIT 1")
            standard_price_book_id = standard_price_book_query['records'][0]['Id']

            # Create standard price book entry
            standard_entry_data = {
                'Pricebook2Id': standard_price_book_id,
                'Product2Id': product_id,
                'UnitPrice': unit_price,
                'IsActive': True,
                'UseStandardPrice': False
            }
            
            # Check if standard entry already exists
            existing_entry_query = self.sf.query(
                f"SELECT Id FROM PricebookEntry WHERE Pricebook2Id = '{standard_price_book_id}' "
                f"AND Product2Id = '{product_id}' LIMIT 1"
            )
            
            if existing_entry_query['records']:
                logger.info(f"Standard Price Book Entry already exists with ID: {existing_entry_query['records'][0]['Id']}")
                return existing_entry_query['records'][0]['Id']
            else:
                standard_response = self.sf.PricebookEntry.create(standard_entry_data)
                logger.info(f"Standard Price Book Entry created with ID: {standard_response['id']}")
                return standard_response['id']

        except Exception as e:
            logger.error(f"Error in create_price_book_entry: {str(e)}")
            raise

    def create_account(self, customer_info):
        """Create a new account (customer) in Salesforce"""
        account_data = {
            'Name': customer_info['name'],
            'Phone': customer_info['phone'],
            'BillingStreet': customer_info['address']
        }
        response = self.sf.Account.create(account_data)
        logger.info(f"Account created with ID: {response['id']}")
        return response['id']

    def create_order(self, account_id, order_details, auth_id, app_sid):
        """Create a new order in Salesforce and push to Firebase"""
        # Get standard price book ID
        standard_pricebook_id = self.sf.query("SELECT Id FROM Pricebook2 WHERE IsStandard = true LIMIT 1")['records'][0]['Id']
        
        # Ensure valid status value
        status = order_details.get('status', 'Draft')
        if status not in ['Draft', 'Activated']:
            status = 'Draft'
        
        # Extract shipping address from payload
        shipping_address = order_details.get('shipping_info', {}).get('shipping_address', {})
        
        # Get notification method
        notification_method = order_details.get('notification_method', 'Email')
        
        # Convert datetime to string in ISO format
        effective_date = order_details['timestamp'].isoformat().split("T")[0]
        
        # Build order data
        order_data = {
            'AccountId': account_id,
            'EffectiveDate': effective_date,  # Use the converted date
            'Status': status,
            'Description': f"Order for {order_details['customer_info']['name']}",
            'Pricebook2Id': standard_pricebook_id,
            # Shipping Address Fields
            'ShippingStreet': shipping_address.get('street'),
            'ShippingCity': shipping_address.get('city'),
            'ShippingState': shipping_address.get('state'),
            'ShippingPostalCode': shipping_address.get('postal_code'),
            'ShippingCountry': shipping_address.get('country'),
            # Billing Address Fields (same as shipping)
            'BillingStreet': shipping_address.get('street'),
            'BillingCity': shipping_address.get('city'),
            'BillingState': shipping_address.get('state'),
            'BillingPostalCode': shipping_address.get('postal_code'),
            'BillingCountry': shipping_address.get('country'),
            # Custom Field for Notification Method
            'notificationMethod__c': notification_method
        }
        
        try:
            response = self.sf.Order.create(order_data)
            order_id = response['id']
            logger.info(f"Order created with ID: {order_id}")
            
            # Add Salesforce order ID to the order details
            order_details['salesforce_id'] = order_id
            
            # Convert datetime fields to strings
            if 'timestamp' in order_details:
                order_details['timestamp'] = order_details['timestamp'].isoformat()
            if 'metadata' in order_details and 'created_at' in order_details['metadata']:
                order_details['metadata']['created_at'] = order_details['metadata']['created_at'].isoformat()
            
            # Push to Firebase Realtime Database using the specified route
            ref = db.reference(f'records/{auth_id}/orders/{app_sid}/{order_id}')
            ref.set(order_details)
            logger.info(f"Order details pushed to Firebase at /records/{auth_id}/{app_sid}/orderDetails/{order_id}")
            
            return order_id
        except Exception as e:
            logger.error(f"Error creating order: {str(e)}")
            raise

    def add_order_items(self, order_id, pricebook_entry_id, quantity, unit_price):
        """Add items to an existing order"""
        item_data = {
            'OrderId': order_id,
            'PricebookEntryId': pricebook_entry_id,
            'Quantity': quantity,
            'UnitPrice': unit_price
        }
        try:
            response = self.sf.OrderItem.create(item_data)
            logger.info(f"Order Item added with ID: {response['id']}")
        except Exception as e:
            logger.error(f"Error adding order item: {str(e)}")
            raise

    def fetch_order_details(self, order_id):
        """Fetch and display order details"""
        try:
            order = self.sf.Order.get(order_id)
            logger.info("\nOrder Details:")
            logger.info(f"ID: {order['Id']}")
            logger.info(f"Status: {order['Status']}")
            logger.info(f"Effective Date: {order['EffectiveDate']}")
            logger.info(f"Description: {order['Description']}")
            logger.info(f"Account ID: {order['AccountId']}")
            logger.info(f"Total Amount: {order.get('TotalAmount', 'N/A')}")
            logger.info(f"Shipping Street: {order.get('ShippingStreet', 'N/A')}")
            logger.info(f"Shipping City: {order.get('ShippingCity', 'N/A')}")
            logger.info(f"Shipping State: {order.get('ShippingState', 'N/A')}")
            logger.info(f"Shipping Postal Code: {order.get('ShippingPostalCode', 'N/A')}")
            logger.info(f"Shipping Country: {order.get('ShippingCountry', 'N/A')}")
            return order
        except Exception as e:
            logger.error(f"Error fetching order details: {str(e)}")
            raise

    def process_order(self, order_payload, auth_id, app_sid):
        """
        Process an order by creating it in Salesforce and Firebase
        Args:
            order_payload (dict): The complete order payload containing all order details
            auth_id (str): The authentication ID for Firebase
            app_sid (str): The application SID for Firebase
        Returns:
            str: The created order ID
        """
        try:
            # Extract details from payload
            order_details = order_payload["order_details"]
            customer_info = order_details["customer_info"]
            product_details = order_details["product_details"]
            addons = order_details["addons"]

            # Validate product details
            if product_details.get("price") is None:
                product_details["price"] = 0.0
                logger.warning("Product price is None, defaulting to 0")

            # Create Product and Price Book Entry for main product
            product_id = self.create_product(
                product_details["model"], 
                f"{product_details.get('storage', 'N/A')} - {product_details.get('color', 'N/A')}", 
                product_details.get("code", "DEFAULT_CODE")  # Add default code if not provided
            )
            pricebook_entry_id = self.create_price_book_entry(product_id, product_details["price"])

            # Create Account (Customer)
            account_id = self.create_account(customer_info)

            # Create Order
            order_id = self.create_order(account_id, order_details, auth_id, app_sid)

            # Add Main Product to Order
            self.add_order_items(order_id, pricebook_entry_id, quantity=1, unit_price=product_details["price"])

            # Add AppleCare if applicable
            if addons.get("apple_care", False):
                apple_care_price = addons.get("apple_care_price", 0.0)
                if apple_care_price is None:
                    apple_care_price = 0.0
                    logger.warning("AppleCare price is None, defaulting to 0")

                apple_care_product_id = self.create_product("AppleCare", "Protection Plan", "APPLE_CARE")
                apple_care_entry_id = self.create_price_book_entry(apple_care_product_id, apple_care_price)
                self.add_order_items(order_id, apple_care_entry_id, quantity=1, unit_price=apple_care_price)

            # Add Accessories
            for accessory in addons.get("accessories", []):
                accessory_price = accessory.get("price", 0.0)
                if accessory_price is None:
                    accessory_price = 0.0
                    logger.warning(f"Accessory price is None, defaulting to 0 for {accessory.get('item')}")

                accessory_product_id = self.create_product(
                    accessory.get("item", "Unknown Accessory"), 
                    "Accessory", 
                    accessory.get("item", "UNKNOWN_ACCESSORY").upper().replace(" ", "_")
                )
                accessory_entry_id = self.create_price_book_entry(accessory_product_id, accessory_price)
                self.add_order_items(order_id, accessory_entry_id, quantity=1, unit_price=accessory_price)

            # Fetch and Display Order Details
            self.fetch_order_details(order_id)
            
            return order_id

        except Exception as e:
            logger.error(f"Error processing order: {str(e)}")
            raise 