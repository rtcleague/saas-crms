from pydantic import BaseModel
from typing import List

class Message(BaseModel):
    role: str
    content: str
    timestamp: str

class Metadata(BaseModel):
    start_time: str
    end_time: str
    call_duration: float

class Conversation(BaseModel):
    messages: List[Message]
    metadata: Metadata

class ConversationPayload(BaseModel):
    conversation: Conversation
    call_id: str
    timestamp: str
    auth_id: str 