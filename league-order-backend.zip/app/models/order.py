from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

class CustomerInfo(BaseModel):
    name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    address: Optional[str] = None

class Accessory(BaseModel):
    item: str
    price: Optional[float] = None

class ProductDetails(BaseModel):
    model: Optional[str] = None
    storage: Optional[str] = None
    color: Optional[str] = None
    price: Optional[float] = None

class Addons(BaseModel):
    apple_care: bool = False
    apple_care_price: Optional[float] = None
    accessories: List[Accessory] = []

class OrderMetadata(BaseModel):
    created_at: datetime
    call_duration: float
    status: str
    version: str = "1.0"

class OrderDetails(BaseModel):
    order_id: str
    timestamp: datetime
    customer_info: CustomerInfo
    product_details: ProductDetails
    addons: Addons
    delivery_method: Optional[str] = None
    notification_method: Optional[str] = None
    status: str

class OrderResponse(BaseModel):
    order_details: OrderDetails
    metadata: OrderMetadata 