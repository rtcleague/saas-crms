from fastapi import APIRouter
from loguru import logger
from services.conversation_service import ConversationService
from models.conversation import ConversationPayload

router = APIRouter()

conversation_service = ConversationService()

# Conversation endpoints
@router.post("/conversation-logs", tags=["conversation"])
async def log_conversation(payload: ConversationPayload):
    logger.info(f"Received conversation for call_id: {payload.call_id}")
    result = await conversation_service.process_conversation(payload.dict())
    return result

# You can add more endpoints here
# Example:
# @router.get("/some-other-endpoint", tags=["other"])
# async def some_other_endpoint():
#     return {"message": "Hello from other endpoint"} 